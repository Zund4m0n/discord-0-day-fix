#!/bin/bash

text_editor=$(which gedit || which xdg-open)

if [ -n "$text_editor" ]; then
    $text_editor test_directory/test_file.txt
fi

